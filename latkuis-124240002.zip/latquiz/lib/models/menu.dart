class Menu {
  final String name;
  final String category;
  final int price;
  final String image;
  final String description;

  const Menu({
    required this.name,
    required this.category,
    required this.price,
    required this.image,
    required this.description,
  });
}
