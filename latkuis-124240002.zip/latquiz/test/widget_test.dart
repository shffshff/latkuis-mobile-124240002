import 'package:flutter_test/flutter_test.dart';
import 'package:latquiz/main.dart';

void main() {
  testWidgets('Login page tampil', (WidgetTester tester) async {
    await tester.pumpWidget(const GacoanApp());
    expect(find.text('Login'), findsOneWidget);
  });
}
